document.documentElement.setAttribute('data-futmago-veicolo', 'estensione');
