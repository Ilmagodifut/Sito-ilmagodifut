(function () {
  var d = document.documentElement;
  d.setAttribute('data-futmago-veicolo', 'estensione');
  try {
    if (chrome.runtime.getURL('').indexOf('chrome-extension://') !== 0) return;
    if (chrome.runtime.getManifest().update_url) {
      d.setAttribute('data-futmago-store', chrome.runtime.id);
    } else {
      var prima = d.getAttribute('data-futmago-manuali');
      d.setAttribute('data-futmago-manuali', (prima ? prima + ' ' : '') + chrome.runtime.id);
    }
  } catch (e) {}
})();
